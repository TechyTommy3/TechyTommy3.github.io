-- Dico Wallpapers Demo --
This is a sample version. Please come to me to buy Dico Wallpapers! For more, go to my website!
-- Files Included --
1.jpg and 2.jpg: Uncropped, low-quality versions of 2 of the new wallpapers in Dico Wallpapers 2022!
Full Resolution Sample 1.png and Full Resolution Sample 2.png: Shows you a small part of a full Dico Wallpapers wallpaper!
readme.txt: You are looking at it!